const express = require("express");
const router = express.Router();

// About page route
router.get("/", function (req, res) {
  res.render("new", { title: "Crie uma Postagem" });
});


module.exports = router;
