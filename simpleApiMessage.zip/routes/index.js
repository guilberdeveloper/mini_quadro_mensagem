const express = require("express");
const router = express.Router();
// Configurando o mecanismo de visualização EJS

const messages = [
  {
    text: "Hi there!",
    user: "Amando",
    added: new Date().toLocaleDateString(),
  },
  {
    text: "Hello World!",
    user: "Charles",
    added: new Date().toLocaleDateString(),
  },
];

// Home page route
router.get("/", function (req, res) {
  res.render("index", { title: "Mini Messageboard", messages: messages });
});

router.post("/new", function (req, res) {
  const { messageText, messageUser } = req.body;

  messages.push({
    text: messageText,
    user: messageUser,
    added: new Date().toLocaleDateString(),
  });
  res.redirect("/");
});

module.exports = router;
